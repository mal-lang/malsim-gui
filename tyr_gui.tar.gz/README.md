# TYR GUI

Angular 18 application
